import React from 'react';

export default class SearchCity extends React.Component {

		render(){

			  <TextField floatingLabelText=" " onChange={this.handleNameState.bind(this)} value={this.props.name}/>
                <br/>
                <RaisedButton label="Get Cities" primary={true} onClick={this.getCities.bind(this)} />
                <br/>
                
		}
}