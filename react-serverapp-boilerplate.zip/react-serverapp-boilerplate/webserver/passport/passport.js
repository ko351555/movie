var passport = require('passport');
var session = require('express-session')
var LocalStrategy = require('passport-local').Strategy;
const User = require('../routes/userschema');



// Configure Passport authenticated session persistence.
//
// In order to restore authentication state across HTTP requests, Passport needs
// to serialize users into and deserialize users out of the session.  The
// typical implementation of this is as simple as supplying the user ID when
// serializing, and querying the user record by ID from the database when
// deserializing.

passport.serializeUser(function(user, done) {
	console.log("serializeUser..",user)
	console.log(user.id);
	done(null, user.id);
});

passport.deserializeUser(function(id, done) {
	User.findById(id,function(err, user){
		if(err)
		{
			done(null,err);
		}
		else {
			done(null, user);
		}
	})
});


passport.use(new LocalStrategy(
	function(username, password, done) {
		User.findOne({ username: username }, function (err, user) {
			console.log("out side if block", user);
			if (err) {  return done(err); }
			if (!user)
			{
				console.log("if block", user);
				return done(null, false, { message: 'Incorrect username.' });

			}
			if (!user.password == password) {
				return done(null, false, { message: 'Incorrect password.' });
			}
			return done(null, user);
		});
	}
	));

module.exports = passport;
