var request = require('supertest');
var expect = require('chai').expect;
var sinon = require('sinon');
var model = require('../movieSchema.js');
/*Stubbing find method of model*/
var modelStub = sinon.stub(model, 'find');

var app = require('../popat.js');
var address = request("http://localhost:8080")

describe('Test my apptest', function(){

  describe('Find jsonitems', function(){

    beforeEach(function(){
      modelStub.yields(null, [{'Title': "Fast and furious", 'Year': '2007','Poster':'http://screenrant.com/wp-content/uploads/fast-furious-8-release-date-2017.jpg','imdbID':'8.9','comments':'very good'}]);
    });

    it('should attempt to find datas', function(done){
      address
      .get('/add')
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function(err, res){
        if (err) return done(err);
        expect(res.body[0].'Title').to.be.equal("Fast and furious");
        done();
      });
    });
  });
  describe('Find jsonitems', function(){

    beforeEach(function(){
      modelStub.yields(null, [{'Title': "Fast and furious", 'Year': '2007','Poster':'http://screenrant.com/wp-content/uploads/fast-furious-8-release-date-2017.jpg','imdbID':'8.9','comments':'very good'}]);
    });

    it('should attempt to find datas', function(done){
      address
      .get('/update/12123134243/verygood')
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function(err, res){
        if (err) return done(err);
        expect(res.body[0].'_id').to.be.equal("12123134243");
        expect(res.body[0].'comments').to.be.equal("very good");


        done();
      });
    });
  });
  describe('Find jsonitems', function(){

    beforeEach(function(){
      modelStub.yields(null, [{'Title': "Fast and furious", 'Year': '2007','Poster':'http://screenrant.com/wp-content/uploads/fast-furious-8-release-date-2017.jpg','imdbID':'8.9','comments':'very good'}]);
    });

    it('should attempt to find datas', function(done){
      address
      .get('/delete/12123134243')
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function(err, res){
        if (err) return done(err);
        expect(res.body[0].'_id').to.be.equal("12123134243");


        done();
      });
    });
  });
  describe('Find jsonitems', function(){

    beforeEach(function(){
      modelStub.yields(null, [{'Title': "Fast and furious", 'Year': '2007','Poster':'http://screenrant.com/wp-content/uploads/fast-furious-8-release-date-2017.jpg','imdbID':'8.9','comments':'very good'}]);
    });

    it('should attempt to find datas', function(done){
      address
      .get('/display')
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function(err, res){
        if (err) return done(err);
        expect(res.body[0]).to.be.equal("res.body[0]");


        done();
      });
    });
  });




});
